"""Clickstream PySpark project package."""
